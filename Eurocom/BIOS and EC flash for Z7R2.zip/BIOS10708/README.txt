--English--
Please follow the instructions below:

1. Before flashing BIOS, please make sure only 2 SO-DIMMs are installed.
   If 4 SO-DIMMs are installed, BIOS flash might fail!

2. After flashing successfully, boot once.

3. Shut down, unplug power supplies. 

4. Reinstall all memory modules and boot.

5. Press F2 while booting and go to Setup>Load default settings.

6. Make desired changes in settings and save.

--Deutsch--
Bitte befolgen Sie die unten stehenden Schritte:

1. Stellen Sie sicher, dass nur 2 Speichermodule eingebaut sind bevor Sie flashen.
   Der Flashvorgang kann fehlschlagen, wenn 4 Module installiert sind!

2. Starten Sie das Gerät nach dem erfolgreichen Flashvorgang.

3. Schalten Sie das Gerät aus und entfernen Sie die Netzteile.

4. Bauen Sie alle Speichermodule wieder ein.

5. Drücken Sie F2 beim Starten und navigieren Sie zum Setup Utility>Laden Sie die "Default Settings".

6. Nehmen Sie die gewünschten Einstellungen vor und und speichern Sie diese.