How to flash whole ROM that include ME:

1. Make sure plugin AC adaptor.
2. Run MeSet.EXE under pure DOS, the system will auto cold boot.
3. Run FlashMe.bat under pure DOS.
4. The system display flash complete message after flash success.
5. Press power button override 4 seconds, and then re-plugin AC adaptor